#ifndef LIBEFP_CLAPACK_H
#define LIBEFP_CLAPACK_H

int c_dsyev(char, char, int, double *, int, double *);

#endif /* LIBEFP_CLAPACK_H */
