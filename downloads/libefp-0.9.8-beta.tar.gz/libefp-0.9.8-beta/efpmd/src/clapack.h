#ifndef EFPMD_CLAPACK_H
#define EFPMD_CLAPACK_H

int c_dsyev(char, char, int, double *, int, double *);

#endif /* EFPMD_CLAPACK_H */
